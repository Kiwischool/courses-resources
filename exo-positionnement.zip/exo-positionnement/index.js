const styleElement = document.getElementById('fetchedStyle')
const getRawCss = async () => {
  const result = await fetch('https://raw.githubusercontent.com/Kiwischool/courses-resources/refs/heads/main/exo-position.css')
  const rawCss = await streamToString(result.body)
  if(rawCss !== undefined && styleElement.childNodes.length === 0) {
    styleElement.innerHTML = rawCss
  }
}

const streamToString = async (stream) => {
  return await new Response(stream).text()
}

getRawCss()